export const environment = {
  apiUrl: 'https://wfcqa.azurewebsites.net/api/walkforCause/',
  production: true
};
